﻿using MySql.Data.MySqlClient;

namespace FlexSpace.DAL
{
    public class ClienteDatos
    {
        private string _conexionString = "Server=localhost;Database=flexspace;Uid=root;Pwd=;";

        public (int Id, string Nombre, string Email, string TipoCliente, int SancionesActivas)? BuscarPorID(int id)
        {
            string query = "SELECT Id, Nombre, Email, TipoCliente, SancionesActivas FROM cliente WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        string nombreDb = reader["Nombre"].ToString();
                        string emailDb = reader["Email"].ToString();
                        string tipoClienteDb = reader["TipoCliente"].ToString();
                        int sancionesActivasDb = Convert.ToInt32(reader["SancionesActivas"]);

                        return (idDb, nombreDb, emailDb, tipoClienteDb, sancionesActivasDb);
                    }
                }
            }

            return null;
        }

        public List <(int Id, string Nombre, string Email, string TipoCliente, int SancionesActivas)> ListarPorSancionados()
        {
            string query = "SELECT Id, Nombre, Email, TipoCliente, SancionesActivas FROM cliente WHERE SancionesActivas > 0";

            var clientes = new List<(int Id, string Nombre, string Email, string TipoCliente, int SancionesActivas)>();

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    while (reader.Read()) 
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        string nombreDb = reader["Nombre"].ToString();
                        string emailDb = reader["Email"].ToString();
                        string tipoClienteDb = reader["TipoCliente"].ToString();
                        int sancionesActivasDb = Convert.ToInt32(reader["SancionesActivas"]);

                        clientes.Add((idDb, nombreDb, emailDb, tipoClienteDb, sancionesActivasDb));
                    }

                    return clientes;
                }
            }

            return null;
        }

        public bool AgregarSanciones(int id)
        {
            string query = "UPDATE cliente SET SancionesActivas = SancionesActivas + 1 WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }
        public bool Eliminar(int id)
        {
            string query = "DELETE FROM cliente WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();

                return filasAfectadas > 0;
            }
        }
    }
}