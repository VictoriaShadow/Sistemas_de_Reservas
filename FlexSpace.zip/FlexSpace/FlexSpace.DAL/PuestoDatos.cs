﻿using MySql.Data.MySqlClient;

namespace FlexSpace.DAL
{
    public class PuestoDatos
    {
        private string _conexionString = "Server=localhost;Database=flexspace;Uid=root;Pwd=;";

        public (int id, string codigo, string tipoPuesto, decimal tarifaBaseXHora)? BuscarPorCodigo(string codigo)
        {
            string query = "SELECT Id, Codigo, TipoPuesto, TarifaBaseXHora FROM puesto WHERE Codigo = @Codigo";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Codigo", codigo);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        string codigoDb = reader["Codigo"].ToString();
                        string tipoPuestoDb = reader["TipoPuesto"].ToString();
                        decimal tarifaBaseXHoraDb = Convert.ToDecimal(reader["TarifaBaseXHora"]);

                        return (idDb, codigoDb, tipoPuestoDb, tarifaBaseXHoraDb);
                    }
                }
            }

            return null;
        }

        public bool Agregar(string codigo, string tipoPuesto, decimal tarifaBaseXHora)
        {
            string query = "INSERT INTO puesto (Codigo, TipoPuesto, TarifaBaseXHora) VALUES (@Codigo, @TipoPuesto, @TarifaBaseXHora)";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Codigo", codigo);
                comando.Parameters.AddWithValue("@TipoPuesto", tipoPuesto);
                comando.Parameters.AddWithValue("@TarifaBaseXHora", tarifaBaseXHora);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool Eliminar(int id)
        {
            string query = "DELETE FROM puesto WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }
    }
}
