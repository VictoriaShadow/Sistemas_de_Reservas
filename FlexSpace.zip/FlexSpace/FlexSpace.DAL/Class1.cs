﻿namespace FlexSpace.DAL
{
    public class Class1
    {
        
    }
}
