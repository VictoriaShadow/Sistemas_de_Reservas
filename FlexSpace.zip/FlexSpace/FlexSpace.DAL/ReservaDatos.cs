﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace FlexSpace.DAL
{
    public class ReservaDatos
    {
        private string _conexionString = "Server=localhost;Database=flexspace;Uid=root;Pwd=;";

        public (int Id, int ClienteId, int PuestoId, DateTime FechaInicio, DateTime FechaFin, string Estado, decimal CostoTotal)? BuscarPorId(int id)
        {
            string query = "SELECT Id, ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal FROM reserva WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        int clienteIdDb = Convert.ToInt32(reader["ClienteId"]);
                        int puestoIdDb = Convert.ToInt32(reader["PuestoId"]);
                        DateTime fechaInicioDb = Convert.ToDateTime(reader["FechaInicio"]);
                        DateTime fechaFinDb = Convert.ToDateTime(reader["FechaFin"]);
                        string estadoDb = reader["Estado"].ToString();
                        decimal costoTotalDb = Convert.ToDecimal(reader["CostoTotal"]);

                        return (idDb, clienteIdDb, puestoIdDb, fechaInicioDb, fechaFinDb, estadoDb, costoTotalDb);
                    }
                }
            }
            return null;
        }

        public bool Agregar(
            int clienteId, int puestoId, DateTime fechaInicio, DateTime fechaFin, string estado, decimal costoTotal)
        {
            string query = "INSERT INTO reserva (ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal) VALUES (@ClienteId, @PuestoId, @FechaInicio, @FechaFin, @Estado, @CostoTotal)";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@ClienteId", clienteId);
                comando.Parameters.AddWithValue("@PuestoId", puestoId);
                comando.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                comando.Parameters.AddWithValue("@FechaFin", fechaFin);
                comando.Parameters.AddWithValue("@Estado", estado);
                comando.Parameters.AddWithValue("@CostoTotal", costoTotal);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool ExisteSuperposicion(int puestoId, DateTime fechaInicio, DateTime fechaFin)
        {
            string query = "SELECT Id FROM reserva  WHERE PuestoId = @PuestoId  AND Estado = 'Confirmada' AND FechaInicio < @FechaFin  AND FechaFin > @FechaInicio";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@PuestoId", puestoId);
                comando.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                comando.Parameters.AddWithValue("@FechaFin", fechaFin);

                conexion.Open();
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    return reader.Read();
                }
            }
        }

        public List<(int Id, int ClienteId, int PuestoId, DateTime FechaInicio, DateTime FechaFin, string Estado, decimal CostoTotal)> ListarFuturasPorPuesto(int puestoId, DateTime ahora)
        {
            string query = "SELECT Id, ClienteId, PuestoId, FechaInicio, FechaFin, Estado, CostoTotal FROM reserva WHERE PuestoId = @PuestoId AND Estado = 'Confirmada' AND FechaInicio > @Ahora ORDER BY FechaInicio";

            List<(int Id, int ClienteId, int PuestoId, DateTime FechaInicio, DateTime FechaFin, string Estado, decimal CostoTotal)> reservas = new();

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@PuestoId", puestoId);
                comando.Parameters.AddWithValue("@Ahora", ahora);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        int clienteIdDb = Convert.ToInt32(reader["ClienteId"]);
                        int puestoIdDb = Convert.ToInt32(reader["PuestoId"]);
                        DateTime fechaInicioDb = Convert.ToDateTime(reader["FechaInicio"]);
                        DateTime fechaFinDb = Convert.ToDateTime(reader["FechaFin"]);
                        string estadoDb = reader["Estado"].ToString();
                        decimal costoTotalDb = Convert.ToDecimal(reader["CostoTotal"]);

                        reservas.Add((
                            idDb,
                            clienteIdDb,
                            puestoIdDb,
                            fechaInicioDb,
                            fechaFinDb,
                            estadoDb,
                            costoTotalDb
                        ));
                    }
                }
            }

            return reservas;
        }

        public bool Cancelar(int id)
        {
            string query = "UPDATE reserva SET Estado = 'Cancelada' WHERE Id = @Id";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }
    }
}
