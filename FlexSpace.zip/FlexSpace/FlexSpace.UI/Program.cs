﻿using FlexSpace.BLL;
using System.Globalization;

    int opcion = 0;
while (opcion != 5)
{
    Console.Clear();

    Console.WriteLine("===== FLEXSPACE =====");
    Console.WriteLine("1. Registrar nueva reserva");
    Console.WriteLine("2. Cancelar reserva");
    Console.WriteLine("3. Consultar reservas activas por puesto");
    Console.WriteLine("4. Listar clientes sancionados");
    Console.WriteLine("5. Salir");
    Console.Write("Seleccione una opción: ");

    opcion = Convert.ToInt32(Console.ReadLine());

    switch (opcion)
    {
        case 1:
            Console.Write("Ingrese id del cliente: ");
            int clienteId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ingrese id del puesto: ");
            int puestoId = Convert.ToInt32(Console.ReadLine());

            string formato = "dd/MM/yyyy HH:mm";

            Console.WriteLine("Por favor, ingresa la fecha y hora de inicio de su reunion en formato (día/mes/año hora:minutos):");
            string fecha1 = Console.ReadLine();

            if (DateTime.TryParseExact(fecha1, formato, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaInicio))
            {
                Console.WriteLine($"Fecha de inicio ingresada con éxito");
            } else {
                Console.WriteLine(" El formato invalido");
            }
            Console.WriteLine("Por favor, ingresa la fecha y hora de finalización de su reunion en formato (día/mes/año hora:minutos):");
            string fecha2 = Console.ReadLine();

            if (DateTime.TryParseExact(fecha2, formato, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechafin))
            {
                Console.WriteLine($"Fecha de finalización ingresada con éxito");
            } else {
                Console.WriteLine(" El formato invalido");
            }

            ReservaBLL reservaBLL = new ReservaBLL();

            decimal? costo = reservaBLL.CalcularCosto(clienteId, puestoId, fechaInicio, fechafin);
            if (costo == null)
            {
                Console.WriteLine("No se pudo calcular el costo de la reserva.");
                Console.ReadKey();
                break;
            }

            decimal costoFinal = costo.Value;

            Console.WriteLine($"Costo total de la reserva: ${costoFinal}");

            Console.WriteLine("¿Desea confirmar la reserva? S/N");
            string respuesta = Console.ReadLine();

            if (respuesta.ToUpper() == "S")
            {
                var reserva = reservaBLL.Agregar(clienteId, puestoId, fechaInicio, fechafin);

                if (reserva != null)
                {
                    Console.WriteLine("Reserva confirmada correctamente.");
                } else {
                    Console.WriteLine("No se pudo realizar la reserva.");
                }
            } else {
                Console.WriteLine("Reserva no confirmada.");
            }
            Console.ReadKey();

            break;

        case 2:
            Console.Write("Ingrese el ID de la reserva a cancelar: ");
            int reservaId = Convert.ToInt32(Console.ReadLine());

            ReservaBLL reservaC = new ReservaBLL();

            var reservaCancelada = reservaC.Cancelar(reservaId);

            if (reservaCancelada != null)
            {
                Console.WriteLine("Reserva cancelada correctamente.");
            }
            else
            {
                Console.WriteLine("No se pudo cancelar la reserva.");
            }

            Console.ReadKey();
            break;

        case 3:
            Console.Write("Ingrese el codigo del puesto: ");
            string codigo = Console.ReadLine();

            PuestoBLL puesto = new PuestoBLL();

            var puestoEncontrado = puesto.BuscarPorCodigo(codigo);

            if (puestoEncontrado == null)
            {
                Console.WriteLine("No se pudo encontrar el puesto");
            } else
            {
                ReservaBLL ReservaP = new ReservaBLL();

                var listadoP = ReservaP.ListarFuturasPorPuesto(puestoEncontrado.id, DateTime.Now);

                if (listadoP.Count == 0)
                {
                    Console.WriteLine("No hay reservas futuras para este puesto.");
                }
                else
                {
                    foreach (var reserva in listadoP)
                    {
                        Console.WriteLine($"Reserva ID: {reserva.id}");
                        Console.WriteLine($"Cliente: {reserva.clienteId}");
                        Console.WriteLine($"Inicio: {reserva.fechaInicio}");
                        Console.WriteLine($"Fin: {reserva.fechaFin}");
                        Console.WriteLine($"Estado: {reserva.estado}");
                        Console.WriteLine($"Costo: ${reserva.costoTotal}");
                        Console.WriteLine("=================================");
                    }
                }
            }

            Console.ReadKey();
            break;

        case 4:
            ClienteBLL cliente = new ClienteBLL();

            var listado = cliente.ListarPorSancionados();

            if (listado.Count == 0)
            {
                Console.WriteLine("No hay clientes sancionados.");
            } else {
                foreach (var sancionado in listado)
                {
                    Console.WriteLine($"Cliente ID: {sancionado.Id}");
                    Console.WriteLine($"Nombre: {sancionado.Nombre}");
                    Console.WriteLine($"Email: {sancionado.Email}");
                    Console.WriteLine($"Tipo de CLiente: {sancionado.TipoCliente}");
                    Console.WriteLine($"Sanciones Activas: {sancionado.SancionesActivas}");
                    Console.WriteLine("=================================");
                }
            }
            Console.ReadKey();
            break;

        case 5:
            Console.WriteLine("Esperamos verlo otra vez!");
            Console.ReadKey();
            break;

        default:
            Console.WriteLine("Opción inválida.");
            Console.ReadKey();
            break;
    }
}