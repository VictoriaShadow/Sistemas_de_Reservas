﻿using FlexSpace.DAL;

namespace FlexSpace.BLL
{
    public class Puestos
    {
        public int id { get; set; }
        public string codigo { get; set; }
        public string tipoPuesto { get; set; }
        public decimal tarifaBaseXHora { get; set; }
    }
    public class PuestoBLL
    {
        private PuestoDatos _datosP = new PuestoDatos();

        public Puestos BuscarPorCodigo(string codigo)
        {
            var resultado = _datosP.BuscarPorCodigo(codigo);
            if (resultado == null) return null;

            return new Puestos
            {
                id = resultado.Value.id,
                codigo = resultado.Value.codigo,
                tipoPuesto = resultado.Value.tipoPuesto,
                tarifaBaseXHora = resultado.Value.tarifaBaseXHora
            };
        }
    }
}