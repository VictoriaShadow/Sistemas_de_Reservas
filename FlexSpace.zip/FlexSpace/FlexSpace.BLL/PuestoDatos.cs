﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace FlexSpace.BLL
{
    internal class PuestoDatos
    {
        private string _conexionString = "Server=localhost;Database=flexspace;Uid=root;Pwd=;";

        public (int Id, string Codigo, string TipoPuesto, decimal TarifaBaseXHora)? BuscarPorCodigo(string codigo)
        {
            string query = "SELECT Id, Codigo, TipoPuesto, TarifaBaseXHora FROM autor WHERE Codigo = @Codigo";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Codigo", codigo);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        string codigoDb = reader["Codigo"].ToString();
                        string tipoPuestoDb = reader["TipoPuesto"].ToString();
                        decimal tarifaBaseXHoraDb = Convert.ToDecimal(reader["TarifaBaseXHora"]);

                        return (idDb, codigoDb, tipoPuestoDb, tarifaBaseXHoraDb);
                    }
                }
            }

            return null;
        }
    }
}
