﻿using FlexSpace.DAL;
using MySqlX.XDevAPI;

namespace FlexSpace.BLL
{
    public class Cliente
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public string TipoCliente { get; set; }
        public int SancionesActivas { get; set; }
    }
    public class ClienteBLL
    {
        private ClienteDatos _datosC = new ClienteDatos();

        public Cliente BuscarPorID(int id)
        {
            var resultado = _datosC.BuscarPorID(id);
            if (resultado == null) return null;

            return new Cliente
            {
                Id = resultado.Value.Id,
                Nombre = resultado.Value.Nombre,
                Email = resultado.Value.Email,
                TipoCliente = resultado.Value.TipoCliente,
                SancionesActivas = resultado.Value.SancionesActivas
            };
        }

        public List<Cliente> ListarPorSancionados()
        {
            ClienteDatos datosc = new ClienteDatos();

            var datosCliente = datosc.ListarPorSancionados();
            var lista = new List<Cliente>();
            foreach (var Cliente in datosCliente)
            {
                lista.Add(new Cliente
                {
                    Id = Cliente.Id,
                    Nombre = Cliente.Nombre,
                    Email = Cliente.Email,
                    TipoCliente = Cliente.TipoCliente,
                    SancionesActivas = Cliente.SancionesActivas
                });
            }
            return lista;
        }

        public bool AgregarSanciones(int id)
        {
            if (id <= 0)
                return false;

            ClienteDatos datosc = new ClienteDatos();

            return datosc.AgregarSanciones(id);
        }


    }
}

