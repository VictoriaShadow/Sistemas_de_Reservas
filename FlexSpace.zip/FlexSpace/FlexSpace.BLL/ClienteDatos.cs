﻿using MySql.Data.MySqlClient;

namespace FlexSpace.BLL
{
    public class ClienteDatos
    {
        private string _conexionString = "Server=localhost;Database=flexspace;Uid=root;Pwd=;";

        public (int Id, string Nombre, string Email, string TipoCliente, int SancionesActivas)? BuscarPorSanciones(int sancionesActivas)
        {
            string query = "SELECT Id, Nombre, Email, TipoCliente, SancionesActivas FROM autor WHERE SancionesActivas = @SancionesActivas";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@SancionesActivas", sancionesActivas);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = Convert.ToInt32(reader["Id"]);
                        string nombreDb = reader["Nombre"].ToString();
                        string emailDb = reader["Email"].ToString();
                        string tipoClienteDb = reader["TipoCliente"].ToString();
                        int sancionesActivasDb = Convert.ToInt32(reader["SancionesActivas"]);

                        return (idDb, nombreDb, emailDb, tipoClienteDb, sancionesActivasDb);
                    }
                }
            }

            return null;
        }
    }
}
