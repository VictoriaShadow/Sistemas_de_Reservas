﻿using System;
using System.Collections.Generic;
using System.Text;
using FlexSpace.DAL;

namespace FlexSpace.BLL
{
    internal class Reserva
    {
    }
}
