﻿using System;
using System.Collections.Generic;
using System.Text;
using FlexSpace.DAL;

namespace FlexSpace.BLL
{
    public class Reservas
    {
        public int id { get; set; }
        public int clienteId { get; set; }
        public int puestoId { get; set; }
        public DateTime fechaInicio { get; set; }
        public DateTime fechaFin { get; set; }
        public string estado { get; set; }
        public decimal costoTotal { get; set; }
    }

    public class ClienteSancionadoException : Exception
    {
        public ClienteSancionadoException(string mensaje): base(mensaje)
        {
        }
    }

    public class ReservaBLL
    {
        private ReservaDatos _datosR = new ReservaDatos();
        private ClienteDatos _datosC = new ClienteDatos();
        private PuestoDatos _datosP = new PuestoDatos();

        public Reservas BuscarPorId(int id)
        {
            var resultado = _datosR.BuscarPorId(id);
            if (resultado == null) return null;

            return new Reservas
            {
                id = resultado.Value.Id,
                clienteId = resultado.Value.ClienteId,
                puestoId = resultado.Value.PuestoId,
                fechaInicio = resultado.Value.FechaInicio,
                fechaFin = resultado.Value.FechaFin,
                estado = resultado.Value.Estado,
                costoTotal = resultado.Value.CostoTotal
            };
        }

        public List<Reservas> ListarFuturasPorPuesto(int puestoId, DateTime ahora)
        {
            ReservaDatos datosr = new ReservaDatos();

            var datosReserva = datosr.ListarFuturasPorPuesto(puestoId, ahora);
            var listaF = new List<Reservas>();

            foreach (var reserva in datosReserva)
            {
                listaF.Add(new Reservas
                {
                    id = reserva.Id,
                    clienteId = reserva.ClienteId,
                    puestoId = reserva.PuestoId,
                    fechaInicio = reserva.FechaInicio,
                    fechaFin = reserva.FechaFin,
                    estado = reserva.Estado,
                    costoTotal = reserva.CostoTotal
                });
            }
            return listaF;
        }

        public Reservas Cancelar(int id)
        {
            var reserva = _datosR.BuscarPorId(id);
            if (reserva == null) return null;

            var hora = reserva.Value.FechaInicio;

            TimeSpan intervalo = hora - DateTime.Now;

            if (intervalo.TotalHours < 2)
            {
                _datosC.AgregarSanciones(reserva.Value.ClienteId);
            }
            _datosR.Cancelar(id);

            return new Reservas
            {
                id = reserva.Value.Id,
                clienteId = reserva.Value.ClienteId,
                puestoId = reserva.Value.PuestoId,
                fechaInicio = reserva.Value.FechaInicio,
                fechaFin = reserva.Value.FechaFin,
                estado = "Cancelada",
                costoTotal = reserva.Value.CostoTotal
            };
        }

        private bool IncluyeFinDeSemana(DateTime fechaInicio, DateTime fechaFin)
        {
            for (DateTime fecha = fechaInicio.Date; fecha <= fechaFin.Date; fecha = fecha.AddDays(1))
            {
                if (fecha.DayOfWeek == DayOfWeek.Saturday ||
                    fecha.DayOfWeek == DayOfWeek.Sunday)
                {
                    return true;
                }
            }

            return false;
        }

        public Reservas Agregar(int id, int clienteId, int puestoId, DateTime fechaInicio, DateTime fechaFin)
        {
            var cliente = _datosC.BuscarPorID(clienteId);
            var superposision = _datosR.ExisteSuperposicion(puestoId, fechaInicio, fechaFin);
            var puesto = _datosP.BuscarPorId(puestoId);

            if (cliente == null)
            {
                return null;
            }
            if (cliente.Value.SancionesActivas >= 3)
            {
                throw new ClienteSancionadoException("El cliente tiene 3 o más sanciones activas");
            }
            if (superposision)
            {
                return null;
            }
            // precio :P
            
            TimeSpan tiempoUsado = fechaFin - fechaInicio;

            if (puesto == null)
            {
                return null;
            }
            var subTotalBase = (decimal)tiempoUsado.TotalHours * puesto.Value.tarifaBaseXHora;
            decimal subTotalPorcentaje = subTotalBase;
            if (cliente.Value.SancionesActivas > 0)
            {
                subTotalPorcentaje -= subTotalBase * 20 / 100;
            } else
            {
                if (IncluyeFinDeSemana(fechaInicio, fechaFin))
                {
                    subTotalPorcentaje += subTotalBase * 15 / 100;
                }
                if (tiempoUsado.TotalHours >= 5)
                {
                    subTotalPorcentaje -= subTotalPorcentaje * 10 / 100;
                }
                if (cliente.Value.TipoCliente == "VIP")
                {
                    subTotalPorcentaje -= subTotalPorcentaje * 5 / 100;
                }
            }

            decimal CostoTotal = subTotalPorcentaje;

            return CostoTotal;
            
        }
    }
}
